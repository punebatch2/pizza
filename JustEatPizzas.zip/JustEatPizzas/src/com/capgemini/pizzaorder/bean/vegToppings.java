package com.capgemini.pizzaorder.bean;

enum vegToppings {
	
//	capsicum {30} , mushroom {50} , jalepeno {70} , paneer {85}

};
