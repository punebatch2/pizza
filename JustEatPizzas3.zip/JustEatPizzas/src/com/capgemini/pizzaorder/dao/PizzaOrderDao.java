package com.capgemini.pizzaorder.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.spi.DirStateFactory.Result;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaException;
import com.capgemini.pizzaorder.utils.DBUtils;


public class PizzaOrderDao implements IPizzaOrderDao{
	
	private Connection dbConnection; // ???

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private int generateNextOrderId() throws SQLException {
		int id = 0;

		String selectQuery = "select pizzaSeq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}
	
	private int generateNextCustId() throws SQLException {
		int id = 0;

		String selectQuery = "select customerSeq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}

	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException, SQLException {
		
		String insertQuery = "insert into pizza_entry values(?,?,?,?)";
		
		
		PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
		
		insertStatement.setInt(1, generateNextOrderId());
		insertStatement.setInt(2, generateNextCustId());
		insertStatement.setDouble(3 ,pizza.getTotalPrice());
		insertStatement.setString(4, pizza.getOrderDate());
		
		
		int rows = insertStatement.executeUpdate();
		
		String insert = "insert into customer_details values(?,?,?,?)";
		
		PreparedStatement insertStatement1 = dbConnection.prepareStatement(insert);
		
		insertStatement1.setInt(1, generateNextCustId());
		insertStatement1.setString(2, customer.getCustName());
		insertStatement1.setString(3 ,customer.getCustAddress());
		insertStatement1.setInt(4, customer.getPhoneNo());
		

		int rows1 = insertStatement1.executeUpdate();
		
		
		
		
		
		
		if(rows>0)
		{
			System.out.println("Added successfully");
			return 1;
		}
		
		else
		{
			System.out.println("Insert failed");
			return 0;
		}
		
	}

	@Override
	public Pizza displayOrder(int orderId) throws PizzaException, SQLException {
		
		Pizza pizza1 = new Pizza();
		
		String retrieveQuery = "select * from pizza_entry where orderId = ?";
		
		PreparedStatement insertStatement = dbConnection.prepareStatement(retrieveQuery);
	
		insertStatement.setInt(1, orderId);
		
		ResultSet result = insertStatement.executeQuery();
		
		result.next();
		
			int orderId1 = result.getInt(1);
			int custId1 = result.getInt(2);
			double totalPrice = result.getDouble(3);
			String orderDate = result.getString(4);
			
//			java.util.Date orderDate1 = new java.util.Date(orderDate.getTime());

			pizza1.setOrderId(orderId1);
//			pizza1.getCustomer().getCustomerId();
			pizza1.setTotalPrice(totalPrice);
			pizza1.setOrderDate(orderDate);
			
			return pizza1;
				
		
		

	}
	
	

}
